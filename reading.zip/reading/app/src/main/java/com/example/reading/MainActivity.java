package com.example.reading;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  {
    private List<Book> bookList=new ArrayList<>();
    private MyDatabaseHelper dbHelper;
    BookAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar =getSupportActionBar();
        if(actionBar!=null){
            actionBar.hide();
        }

        dbHelper=new MyDatabaseHelper(this,"BookStore.db",null,2);
        ImageButton settingButton=(ImageButton)findViewById(R.id.settingButton);
        ImageButton addButton=(ImageButton)findViewById(R.id.addButton);
        ImageButton refresh=(ImageButton)findViewById(R.id.refresh);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        settingButton.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,Setting.class);
                startActivity(intent);
            }
        });
        addButton.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,FileSearch.class);
                startActivity(intent);
            }
        });
        initBooks();
        RecyclerView recyclerView=(RecyclerView)findViewById(R.id.book_view);
        GridLayoutManager layoutManager=new GridLayoutManager(this,3);
        layoutManager.setOrientation(GridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        adapter=new BookAdapter(bookList);
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new BookAdapter.OnItemClickListener() {
            @Override
            public void onItemLongClick(View view, final int position) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                //设置标题
                builder.setTitle("是否确定将此小说移除？");
                //设置确定按钮
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Book book=bookList.get(position);
                        String name=book.getName();
                        SQLiteDatabase db=dbHelper.getWritableDatabase();
                        db.delete("Book","name=?",new String[]{name});
                        adapter.remove(position);



                        Toast.makeText(MainActivity.this, "已移除", Toast.LENGTH_LONG).show();
                    }
                });

                //设置取消按钮 如果只是要取消对话框 点击事件可以传NULL
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                //显示对话框
                builder.show();


            }

            @Override
            public void onItemClick(View view, int position) {
                Book book=bookList.get(position);
                Intent intent=new Intent(MainActivity.this,ReadingActivity.class);
                intent.putExtra("path",book.getPath());
                intent.putExtra("name",book.getName());
                startActivity(intent);


            }

        });


    }
    private void initBooks(){

//        Book book2 =new Book(getText(R.string.book2).toString(),R.drawable.book);
//        bookList.add(book2);
//        Book book3 =new Book(getText(R.string.book3).toString(),R.drawable.book);
//        bookList.add(book3);
//        Book book4 =new Book(getText(R.string.book4).toString(),R.drawable.book);
//        bookList.add(book4);
//        Book book5 =new Book(getText(R.string.book5).toString(),R.drawable.book);
//        bookList.add(book5);
//        Book book6 =new Book(getText(R.string.book6).toString(),R.drawable.book);
//        bookList.add(book6);
//        Book book7 =new Book(getText(R.string.book7).toString(),R.drawable.book);
//        bookList.add(book7);
//        Book book8 =new Book(getText(R.string.book8).toString(),R.drawable.book);
//        bookList.add(book8);
//        Book book9 =new Book(getText(R.string.book9).toString(),R.drawable.book);
//        bookList.add(book9);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        Cursor cursor=db.query("Book",null,null,null,null,null,null);
        if(cursor.moveToFirst()){
            do{
                String name=cursor.getString(cursor.getColumnIndex("name"));
                String path=cursor.getString(cursor.getColumnIndex("path"));
                Book book =new Book(name,R.drawable.book,path);
                bookList.add(book);
            }while (cursor.moveToNext());
        }cursor.close();

    }

}
