package com.example.reading;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class SizeSetting extends AppCompatActivity implements View.OnClickListener {

    private TextView size_12;
    private TextView size_14;
    private TextView size_16;
    private TextView size_18;
    private TextView size_20;
    private TextView size_22;
    private TextView size_24;
    int size;
    final int RESULT_CODE2=102;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.size_setting);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        size_12=findViewById(R.id.size_12);
        size_14=findViewById(R.id.size_14);
        size_16=findViewById(R.id.size_16);
        size_18=findViewById(R.id.size_18);
        size_20=findViewById(R.id.size_20);
        size_22=findViewById(R.id.size_22);
        size_24=findViewById(R.id.size_24);
        size_12.setOnClickListener(this);
        size_14.setOnClickListener(this);
        size_16.setOnClickListener(this);
        size_18.setOnClickListener(this);
        size_20.setOnClickListener(this);
        size_22.setOnClickListener(this);
        size_24.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.size_12:
                size=12;
                break;
            case R.id.size_14:
                size=14;
                break;
            case R.id.size_16:
                size=16;
                break;
            case R.id.size_18:
                size=18;
                break;
            case R.id.size_20:
                size=20;
                break;
            case R.id.size_22:
                size=22;
                break;
            case R.id.size_24:
                size=24;
                break;
                default:
        }
        Intent intent=new Intent();
        intent.putExtra("size",size);
        setResult(RESULT_CODE2,intent);
        finish();
    }
}
