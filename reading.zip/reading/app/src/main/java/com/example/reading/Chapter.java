package com.example.reading;

public class Chapter {

    private String chapter_name;

    private int chapter_position;
    private int chapter_byte_position;
    public Chapter() {
        this.chapter_name=chapter_name;
        this.chapter_position=chapter_position;

}

    public int getChapter_byte_position() {
        return chapter_byte_position;
    }

    public void setChapter_name(String chapter_name) {
        this.chapter_name = chapter_name;
    }

    public int getChapter_position() {
        return chapter_position;
    }

    public void setChapter_position(int chapter_position) {
        this.chapter_position = chapter_position;
    }

    public void setChapter_byte_position(int chapter_byte_position) {
        this.chapter_byte_position = chapter_byte_position;
    }

    public String getChapter_name() {
        return chapter_name;
    }

}
