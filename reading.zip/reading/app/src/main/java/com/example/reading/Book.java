package com.example.reading;

public class Book {
    private String name;
    private int imageId;
    private String path;
    public Book(String name,int imageId,String path) {
        this.name=name;
        this.imageId=imageId;
        this.path=path;
    }
    public String getName(){
        return name;
    }

    public String getPath() {
        return path;
    }

    public int getImageId(){
        return imageId;
    }
}