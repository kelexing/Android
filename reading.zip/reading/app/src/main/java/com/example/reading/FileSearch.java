package com.example.reading;

import android.app.Activity;


import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class FileSearch extends Activity implements AdapterView.OnItemClickListener,View.OnClickListener {

    private ListView fileList;
    private TextView fileCP;
    private SimpleAdapter sAdapter;
    private List<Map<String, Object>> aList;
    private String baseFile;
    private MyDatabaseHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        dbHelper=new MyDatabaseHelper(this,"BookStore.db",null,2);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.scroll_list_filesearch);

        baseFile = GetFilesUtils.getInstance().getBasePath();//获取当前所在位置


        fileList = (ListView) findViewById(R.id.list);//初始化fileList，用于显示文件列表
        fileCP = (TextView) findViewById(R.id.current_position);//初始化fileCP，用于显示当前所在位置
        fileCP.setText(baseFile);
        ImageButton return_Button=(ImageButton)findViewById(R.id.return_Button);
        return_Button.setOnClickListener(this);//为fileCP设置单击事件监听器
        aList = new ArrayList<Map<String, Object>>();
        sAdapter = new SimpleAdapter(this, aList, R.layout.list_filesearch_item, new String[]{"fImg", "fName", "fInfo"},
                new int[]{R.id.item_img, R.id.item_name, R.id.item_info});
        fileList.setAdapter(sAdapter);
        fileList.setOnItemClickListener(this);
        try {
            loadFolderList(baseFile);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private void loadFolderList(String file) throws IOException {
        List<Map<String, Object>> list = GetFilesUtils.getInstance().getSonNode(file);
        if (list != null) {
            Collections.sort(list, GetFilesUtils.getInstance().defaultOrder());
            aList.clear();
            for (Map<String, Object> map : list) {
                String fileType = (String) map.get(GetFilesUtils.FILE_INFO_TYPE);
                Map<String, Object> gMap = new HashMap<String, Object>();
                if (map.get(GetFilesUtils.FILE_INFO_ISFOLDER).equals(true)) {
                    gMap.put("fIsDir", true);
                    gMap.put("fImg", R.drawable.ic_dir);
                    gMap.put("fInfo", map.get(GetFilesUtils.FILE_INFO_NUM_SONDIRS) + "个文件夹和" +
                            map.get(GetFilesUtils.FILE_INFO_NUM_SONFILES) + "个文件");
                } else {
                    gMap.put("fIsDir", false);
                    if (fileType.equals("txt")) {
                        gMap.put("fImg", R.drawable.ic_txt);
                    } else {
                        gMap.put("fImg", R.drawable.ic_others);
                    }
                    gMap.put("fInfo", "文件大小:" + GetFilesUtils.getInstance().getFileSize(map.get(GetFilesUtils.FILE_INFO_PATH).toString()));
                }
                gMap.put("fName", map.get(GetFilesUtils.FILE_INFO_NAME));
                gMap.put("fPath", map.get(GetFilesUtils.FILE_INFO_PATH));
                aList.add(gMap);
            }
        } else {
            aList.clear();
        }
        sAdapter.notifyDataSetChanged();
        fileCP.setText(file);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position,
                            long id) {
        try {
            if (aList.get(position).get("fIsDir").equals(true)) {
                loadFolderList(aList.get(position).get("fPath").toString());
            }
            else if(aList.get(position).get("fImg").equals(R.drawable.ic_txt)){
                SQLiteDatabase db=dbHelper.getWritableDatabase();
                ContentValues values=new ContentValues();
                values.put("name",aList.get(position).get("fName").toString());
                values.put("path",aList.get(position).get("fPath").toString());
                db.insert("Book",null,values);
                Intent intent=new Intent(FileSearch.this,ReadingActivity.class);

                intent.putExtra("path",aList.get(position).get("fPath").toString());
                intent.putExtra("name",aList.get(position).get("fName").toString());
                startActivity(intent);
            }
            else{
                Toast.makeText(this,aList.get(position).get("fPath").toString() , Toast.LENGTH_SHORT).show();
//                Intent intent=new Intent(FileSearch.this,ReadingActivity.class);
//
//               startActivity(intent);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        if (v.getId() == R.id.return_Button) {
            try {
                String folder = GetFilesUtils.getInstance().getParentPath(fileCP.getText().toString());
                if (folder == null) {
                    Toast.makeText(this, "无父目录，待处理", Toast.LENGTH_SHORT).show();
                } else {
                    loadFolderList(folder);
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
}

