package com.example.reading;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class BackgroundColorSetting extends AppCompatActivity implements View.OnClickListener {

    private TextView white;
    private TextView orange1;
    private TextView burlywood;
    private TextView aqua;
    int color;
    final int RESULT_CODE3=103;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.background_color_setting );
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        white=findViewById(R.id.white);
        orange1=findViewById(R.id.orange1);
        aqua=findViewById(R.id.aquq);
        burlywood=findViewById(R.id.burlywood);
        white.setOnClickListener(this);
        orange1.setOnClickListener(this);
        aqua.setOnClickListener(this);
        burlywood.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.white:
                color=R.color.white;
                break;
            case R.id.orange1:
                color=R.color.orange1;
                break;
            case R.id.aquq:
                color=R.color.aqua;
                break;
            case R.id.burlywood:
                color=R.color.burlywood;
                break;

            default:
        }
        Intent intent=new Intent();
        intent.putExtra("background_color",color);
        setResult(RESULT_CODE3,intent);
        finish();
    }
}
