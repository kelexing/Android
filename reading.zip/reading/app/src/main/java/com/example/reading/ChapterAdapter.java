package com.example.reading;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import static android.app.Activity.RESULT_OK;

public class ChapterAdapter extends RecyclerView.Adapter<ChapterAdapter.ViewHolder>{
    private List<Chapter> ChapterList;
    private ChapterListItemClickListener listener;
    static class ViewHolder extends RecyclerView.ViewHolder{
        View chapterView;
        TextView chapterName;

        public ViewHolder(View view){
            super(view);
            chapterView=view;
            chapterName=(TextView)view.findViewById(R.id.chapter_item);
        }
    }
    public ChapterAdapter(List<Chapter> chapterList){
        ChapterList=chapterList;
    }

    @NonNull



    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.chapter_item,parent,false);
        final ViewHolder holder=new ViewHolder(view);
        holder.chapterView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position=holder.getAdapterPosition();
                Chapter chapter=ChapterList.get(position);
                Log.d("chapter","章节"+chapter.getChapter_byte_position());

            }
        });
        return holder;
    }
    public void setClickListener(ChapterListItemClickListener listener){
        this.listener=listener;
    }
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        Chapter chapter=ChapterList.get(position);

        holder.chapterName.setText(chapter.getChapter_name());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                if(listener!=null){
                    int pos=holder.getLayoutPosition();
                    listener.onClick(holder.itemView,pos);
                }
            }
        });
    }
    public interface ChapterListItemClickListener{
        void onClick(View view,int position);
    }
    public int getChapterByte(int position){
        Chapter chapter=ChapterList.get(position);
        return chapter.getChapter_byte_position();
    }

    @Override
    public int getItemCount() {
        return ChapterList.size();
    }
}
