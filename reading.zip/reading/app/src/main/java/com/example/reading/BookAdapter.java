package com.example.reading;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder>{
    private List<Book> mBookList;

    static class ViewHolder extends RecyclerView.ViewHolder{
        View bookView;
        ImageView bookImage;
        TextView bookName;

        public ViewHolder(View view){
            super(view);
            bookView=view;
            bookImage=(ImageView)view.findViewById(R.id.book_image);
            bookName=(TextView)view.findViewById(R.id.book_name);
        }
    }
    public BookAdapter(List<Book> bookList){
        mBookList=bookList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.book_item,parent,false);
        final ViewHolder holder=new ViewHolder(view);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mOnItemClickListener!=null) {
                    int pos = holder.getLayoutPosition();
                    mOnItemClickListener.onItemClick(holder.itemView,pos);
                }
//                int position=holder.getAdapterPosition();
//                Book book=mBookList.get(position);
//                Intent intent=new Intent(v.getContext(),ReadingActivity.class);
//                intent.putExtra("path",book.getPath());
//                intent.putExtra("name",aList.get(position).get("fName").toString());
//                startActivity(intent);
//                Toast.makeText(v.getContext(),"你点击了"+book.getName(),Toast.LENGTH_SHORT).show();
            }
        });
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                int layoutPositon=holder.getLayoutPosition();
                mOnItemClickListener.onItemLongClick(holder.itemView,layoutPositon);
                return false;
            }
        });
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Book book=mBookList.get(position);
        holder.bookImage.setImageResource(book.getImageId());
        holder.bookName.setText(book.getName());
    }
    public interface OnItemClickListener{
        void onItemLongClick(View view,int position);
        void onItemClick(View view,int position);
    }
    public OnItemClickListener mOnItemClickListener;
    public void setOnItemClickListener(OnItemClickListener onItemClickListener){
        mOnItemClickListener = onItemClickListener;
    }
    public void remove(int i){
        mBookList.remove(i);

        notifyItemRemoved(i);
        notifyDataSetChanged();
    }
    public void refresh(){
        notifyDataSetChanged();
    }
    @Override
    public int getItemCount() {
        return mBookList.size();
    }
}
