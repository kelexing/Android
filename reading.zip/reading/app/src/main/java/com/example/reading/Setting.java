package com.example.reading;

import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class Setting extends AppCompatActivity {
    PopupWindow pop;
    ImageButton next_page;
    ImageButton previous_page;
    View view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        final LinearLayout cs=(LinearLayout)findViewById(R.id.cs);
        view= LayoutInflater.from(this).inflate(R.layout.menu_reading,null);//引入窗口配置文件
//        next_page=(ImageButton)findViewById(R.id.next_page);
//        previous_page=(ImageButton)findViewById(R.id.previous_page);//初始化按钮
        pop=new PopupWindow(view, RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT,true);
        pop.setFocusable(true);//设置PopupWindow可获得焦点
        pop.setTouchable(true);//设置PopupWindow可触摸
        pop.setOutsideTouchable(true);//设置非PopupWindow区域可触摸
        pop.setAnimationStyle(R.style.AnimBottom);//设置PopupWindow显示和隐藏的动画
//        ColorDrawable cd=new ColorDrawable(0x00ffffff);
        cs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(pop.isShowing()){
                    pop.dismiss();
                }
                else{
                    pop.setBackgroundDrawable(new BitmapDrawable());
                    findViewById(R.id.cs).post(new Runnable() {
                        @Override
                        public void run() {
                            pop.showAtLocation(cs, Gravity.BOTTOM,0,0);
                        }
                    });

                }
            }});
//        pop.setBackgroundDrawable(new BitmapDrawable());
//        findViewById(R.id.cs).post(new Runnable() {
//            @Override
//            public void run() {
//                pop.showAtLocation(cs,Gravity.BOTTOM,0,0);
//            }
//        });



    }


}
