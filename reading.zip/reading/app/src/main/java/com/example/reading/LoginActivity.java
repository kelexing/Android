package com.example.reading;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
public class LoginActivity extends AppCompatActivity {

    private EditText editText1;
    private EditText editText2;
    private TextView login;
    private TextView register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        editText1=(EditText)findViewById(R.id.id);
        editText2=(EditText)findViewById(R.id.password);
        login=(TextView)findViewById(R.id.login);
        register=(TextView)findViewById(R.id.register);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id=editText1.getText().toString();
                String password=editText2.getText().toString();
                if(id.length()>0&&password.length()>0)
                {
                    sendRequestWithHttpClient();
                }
                else{
                    Toast.makeText(LoginActivity.this,"请输入账号密码",Toast.LENGTH_LONG).show();
                }
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });

    }
    private void sendRequestWithHttpClient() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{

                    ContentValues postParams = new ContentValues();
                    //要传递的参数
                    postParams.put("accountid", editText1.getText().toString());
                    postParams.put("password", editText2.getText().toString());
                    String s=  UrlManager.httpUrlConnectionPost("/servlet/LoginServlet",postParams);
                    if(s.startsWith("success")) {
                        Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                        startActivity(intent);
                        LoginActivity.this.finish();
                    }else  if(s.startsWith("fail")) {
                        Looper.prepare();
                        Toast toast= Toast.makeText(LoginActivity.this, "登录失败", Toast.LENGTH_SHORT);
                        toast.show();
                        Looper.loop();
                    }
                    Thread.sleep(2000);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }).start();//这个start()方法不要忘记了

    }


}


