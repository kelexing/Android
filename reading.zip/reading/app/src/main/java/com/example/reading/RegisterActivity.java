package com.example.reading;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
public class RegisterActivity extends AppCompatActivity {

    private EditText editText1_register;
    private EditText editText2_register;

    private TextView register_register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        editText1_register = (EditText) findViewById(R.id.id_register);
        editText2_register = (EditText) findViewById(R.id.password_register);
        register_register = (TextView) findViewById(R.id.register_register);
        register_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = editText1_register.getText().toString();
                String password = editText2_register.getText().toString();
                if (id.length() > 0 && password.length() > 0) {
                    sendRequestWithHttpClient();

                } else {
                    Toast.makeText(RegisterActivity.this, "请输入账号密码进行注册", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
    private void sendRequestWithHttpClient() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{

                    ContentValues postParams = new ContentValues();
                    //要传递的参数
                    postParams.put("accountid", editText1_register.getText().toString());
                    postParams.put("password", editText2_register.getText().toString());
                    String s=  UrlManager.httpUrlConnectionPost("/RegisterServlet",postParams);
                    if(s.startsWith("success")) {
                        Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
                        startActivity(intent);
                        RegisterActivity.this.finish();
                    }else  if(s.startsWith("fail")) {
                        Looper.prepare();
                        Toast toast= Toast.makeText(RegisterActivity.this, "注册失败，请重试", Toast.LENGTH_SHORT);
                        toast.show();
                        Looper.loop();
                    }
                    Thread.sleep(2000);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }).start();//这个start()方法不要忘记了

    }

}