package com.example.reading;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;


public class ReadingActivity extends AppCompatActivity implements View.OnClickListener, View.OnKeyListener {
    private int screenHeight,screenWidth;//view尺寸
    private int lineNumber;//行数
    private int fontSize;
    private int fileLength=0;
    private TextView reading_detail;
    private RelativeLayout readView;
    private RelativeLayout relativeLayout;

    public static final int UPDATE_TEXT=1;

    private long pages;
    private long bytescount;
    private int currentpage;
    private int currentbyte;
    private RandomAccessFile readFile;
    File file;
    private int pageNumber;

    static int  height;
    static int width;





    private int lineHeight;
    private int lineCount;
    private int lineWord;
    final int RESULT_CODE1=101;
    final int REQUEST_CODE1=1;
    final int RESULT_CODE2=102;
    final int REQUEST_CODE2=2;
    final int RESULT_CODE3=103;
    final int REQUEST_CODE3=3;
    final int RESULT_CODE4=104;
    final int REQUEST_CODE4=4;
    String book_name;

    private List<Chapter> chapterList = new ArrayList<>();

    PopupWindow pop;
    PopupWindow pop1;
    ImageButton next_page;
    ImageButton previous_page;
    ImageButton chapter;
    ImageButton bookmark;
    ImageButton size;
    ImageButton background_color;
    ImageButton bookmark_save;
    Page page;

    String encode;
    String path;
    int backgroundcolor;
    int TextSize;

    private float touchDownX,touchUpX;


    Intent intent=getIntent();



    View view;
    View view1;
//    private Handler handler=new Handler() {
//        @Override
//        public void publish(LogRecord record) {
//
//        }
//
//        @Override
//        public void flush() {
//
//        }
//
//        @Override
//        public void close() throws SecurityException {
//
//        }
//    }



    @SuppressLint("HandlerLeak")
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reading);



        ActionBar actionBar =getSupportActionBar();
        if(actionBar!=null){
            actionBar.hide();
        }
        Log.e("oncreate","d"+currentpage);
        final RelativeLayout readView=(RelativeLayout) findViewById(R.id.readView);
        view= LayoutInflater.from(this).inflate(R.layout.menu_reading,null);//引入窗口配置文件
//        next_page=(ImageButton)findViewById(R.id.next_page);
//        previous_page=(ImageButton)findViewById(R.id.previous_page);//初始化按钮


        pop=new PopupWindow(view, RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT,true);
        pop.setFocusable(true);//设置PopupWindow可获得焦点
        pop.setTouchable(true);//设置PopupWindow可触摸
        pop.setOutsideTouchable(true);//设置非PopupWindow区域可触摸
        pop.setAnimationStyle(R.style.AnimBottom);//设置PopupWindow显示和隐藏的动画
        chapter=(ImageButton)view.findViewById(R.id.chapter);
        chapter.setOnClickListener(this);
        background_color=(ImageButton)view.findViewById(R.id.background_color);
        background_color.setOnClickListener(this);
        bookmark=(ImageButton)view.findViewById(R.id.bookmark);
        bookmark.setOnClickListener(this);
        size=(ImageButton)view.findViewById(R.id.size);
        size.setOnClickListener(this);
        bookmark_save=(ImageButton)view.findViewById(R.id.bookmark_save);
        bookmark_save.setOnClickListener(this);



//        ColorDrawable cd=new ColorDrawable(0x00ffffff);

        view1= LayoutInflater.from(this).inflate(R.layout.chapter_catalogue,null);//引入窗口配置文件
//        next_page=(ImageButton)findViewById(R.id.next_page);
//        previous_page=(ImageButton)findViewById(R.id.previous_page);//初始化按钮
        pop1=new PopupWindow(view1, RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT,true);
        pop1.setFocusable(true);//设置PopupWindow可获得焦点
        pop1.setTouchable(true);//设置PopupWindow可触摸
        pop1.setOutsideTouchable(true);//设置非PopupWindow区域可触摸
        pop1.setAnimationStyle(R.style.AnimLeft);//设置PopupWindow显示和隐藏的动画

        reading_detail = (TextView) findViewById(R.id.reading_detail);
        SharedPreferences preferences=getSharedPreferences("Size",MODE_PRIVATE);
        TextSize=preferences.getInt("TextSize",20);
        reading_detail.setTextSize(TextSize);

        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        screenHeight = outMetrics.heightPixels;
        screenWidth=outMetrics.widthPixels;





        path=getIntent().getStringExtra("path");//获取点击文件路径
        try {
            encode=resolveCode(path);
        } catch (Exception e) {
            e.printStackTrace();
        }
        book_name=getIntent().getStringExtra("name");
        SharedPreferences preferences2=getSharedPreferences(book_name,MODE_PRIVATE);
        currentpage=preferences2.getInt("bookmark",0);
        page=new Page(path,currentpage);
        Log.e("page","d"+currentpage);
        page.setEncode(encode);
        page.setScreenHeight(screenHeight);
        page.setScreenWidth(screenWidth);
        Log.d("tag","page"+screenWidth);

        String content=page.getPre();
        reading_detail.setText(content);
        SharedPreferences preferences1=getSharedPreferences("Color",MODE_PRIVATE);
        backgroundcolor=preferences1.getInt("Background_Color",R.color.burlywood);

        reading_detail.setBackgroundColor(getResources().getColor(backgroundcolor));//动态设置背景颜色

        reading_detail.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {


                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    touchDownX=event.getX();
                    return true;
                }else if(event.getAction()==MotionEvent.ACTION_UP){
                    touchUpX=event.getX();
                    if(touchUpX-touchDownX>100){

                        String content=page.getPre();
                        reading_detail.setText(content);
                    }else if(touchDownX-touchUpX>100){
                        String content=page.getNext();
                        reading_detail.setText(content);
                    }
                    else{
                        if(pop.isShowing()){
                            pop.dismiss();
                        }
                        else if(pop1.isShowing()){
                            pop.dismiss();
                        }
                        else{
                            pop.setBackgroundDrawable(new BitmapDrawable());
                            findViewById(R.id.readView).post(new Runnable() {
                                @Override
                                public void run() {
                                    pop.showAtLocation(readView, Gravity.BOTTOM,0,0);

                                }
                            });}

//

                    }
                }
                return true;
            }
        });


        chapter.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
//                                        pop.dismiss();
//                                        pop1.setBackgroundDrawable(new BitmapDrawable());
//                                        findViewById(R.id.readView).post(new Runnable() {
//                                            @Override
//                                                public void run() {
//                                                     pop1.showAtLocation(readView, Gravity.LEFT,0,0);
//
//                                            }
//                                        });

                                        Intent intent1=new Intent(ReadingActivity.this,ChapterMenu.class);
                                        intent1.putExtra("path",path);

                                        startActivityForResult(intent1,REQUEST_CODE1);


                                        }

        });
        size.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ReadingActivity.this,SizeSetting.class);
                startActivityForResult(intent,REQUEST_CODE2);
            }

        });
        background_color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1=new Intent(ReadingActivity.this,BackgroundColorSetting.class);

                startActivityForResult(intent1,REQUEST_CODE3);


            }

        });
        bookmark_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int c=page.getCurrentpage();
                SharedPreferences.Editor editor=getSharedPreferences(book_name,MODE_PRIVATE).edit();
                editor.putInt("bookmark",c);
                Toast.makeText(ReadingActivity.this,"书签已保存:"+c+"页",Toast.LENGTH_SHORT).show();
                editor.apply();
            }
        });
        bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences preferences2=getSharedPreferences(book_name,MODE_PRIVATE);
                currentpage=preferences2.getInt("bookmark",0);
                Log.e("byte","d"+currentpage);
                String content=page.change_page(currentpage);
                reading_detail.setText(content);

            }

        });



//        initChapter(path);
//        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.chapter);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
//        recyclerView.setLayoutManager(layoutManager);
//        ChapterAdapter adapter = new ChapterAdapter(chapterList);
//        recyclerView.setAdapter(adapter);
        }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case REQUEST_CODE1:
                if(resultCode==RESULT_CODE1){
                    currentbyte=data.getIntExtra("chapterbyte",0);
                    this.currentpage=currentbyte/2000;
                    Log.e("byte","d"+currentpage);
                    String content=page.change_page(currentpage);
                    reading_detail.setText(content);

                }
                break;

            case REQUEST_CODE2:
                if(resultCode==RESULT_CODE2){
                    TextSize=data.getIntExtra("size",0);
                    this.TextSize=TextSize;
                    reading_detail.setTextSize(TextSize);
                    Log.e("size","d"+TextSize);
                    SharedPreferences.Editor editor=getSharedPreferences("Size",MODE_PRIVATE).edit();
                    editor.putInt("TextSize",TextSize);
                    editor.apply();

                }
                break;
            case REQUEST_CODE3:
                if(resultCode==RESULT_CODE3){
                    backgroundcolor=data.getIntExtra("background_color",0);
                    this.backgroundcolor=backgroundcolor;
                    reading_detail.setBackgroundColor(getResources().getColor(backgroundcolor));

                    SharedPreferences.Editor editor=getSharedPreferences("Color",MODE_PRIVATE).edit();
                    editor.putInt("Background_Color",backgroundcolor);
                    editor.apply();

                }
                break;

            default:
        }
    }


//    private void initChapter(String path){
//
//        String encoding= null;
//        try {
//            encoding = resolveCode(path);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        int i = 0;
//        try {
//            InputStreamReader isr = new InputStreamReader(new FileInputStream(new File(path)), encoding);
//            BufferedReader reader = new BufferedReader(isr);
//            String temp;
//            Chapter chapter;
//            while ((temp = reader.readLine()) != null) {
//                //这里关键字可以是章，也可以是其他的什么
//                if(temp.contains("第")&&temp.contains("章")){
//                    chapter = new Chapter(temp);
//                    Log.d("123","章节"+temp);
//
//                    chapterList.add(chapter);
//                }
//                i++;
//            }
//        } catch (FileNotFoundException f) {
//            f.printStackTrace();
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//    }

















    //        reading_detail.measure(0,0);
//        height=reading_detail.getMeasuredHeight();
//        width=reading_detail.getMeasuredWidth();

//        reading_detail.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
//            @Override
//            public boolean onPreDraw() {
//                reading_detail.getViewTreeObserver().removeOnPreDrawListener(this);
//                height =reading_detail.getHeight();
////                Log.d("height",  "height =" + height);
//                return true;
//            }
//        });



//        reading_detail.post(new Runnable() {
//                      @Override
//                      public void run() {
//                          Log.d("height","height="+reading_detail.getHeight());
//
//                      }
//                  }
//
//        );













//        reading_detail.setText(loadData(s));
//        readView=(RelativeLayout) findViewById(R.id.readView);
//        readView.setBackgroundColor(Color.parseColor("#ffe4c4"));//动态设置背景颜色
//        reading_detail.setOnClickListener(new View.OnClickListener() {
//            @SuppressLint("WrongViewCast")
//            @Override
//            public void onClick(View v) {
//               relativeLayout=(RelativeLayout)findViewById(R.id.menu_reading);
//
//
//            }
//        });





//        handler = new Handler() {
//            @Override
//            public void handleMessage(Message msg) {
//                // msg就是子线程发送过来的消息
//                // 修改text内容
//                reading_detail.setText(msg.obj.toString());
//            }
//        };
//
//        // 建立进度条
//        final ProgressDialog dialog = new ProgressDialog(this);
//        // 设置为水平进度条
//        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
//        dialog.setTitle("提示");
//        dialog.setMessage("正在加载数据, 请稍候...");
//        // 设置最大值
//        File f = new File(intent.getStringExtra("path"));
//        dialog.setMax((int) f.length());
//
//        dialog.show();
//
//        Thread t = new Thread() {
//            @Override
//            public void run() {
//                // 接收参数,并根据参数建立文件对象
//                File f = new File(intent.getStringExtra("path"));
//                // 使用IO流读取
//                try {
//                    BufferedReader reader = new BufferedReader(
//                            new InputStreamReader(new FileInputStream(f), "GBK"));
//                    String line = null;
//                    StringBuilder builder = new StringBuilder();
//
//                    // 定义保存读取内容大小的变量
//                    int size = 0;
//
//                    while ((line = reader.readLine()) != null) {
//                        builder.append(line + "\r\n");
//                        // 当读取了一部分内容后,根据读取内容的大小,然后增长进度
//                        size += line.getBytes().length;
//                        // 每增加超过10k的内容,就改变一次进度条
//                        if (size >= 10240) {
//                            dialog.incrementProgressBy(size);
//                            size = 0;
//                            // 睡眠一段时间
//                            Thread.sleep(5);
//                        }
//                    }
//
//                    reader.close();
//
//                    // detail.setText(builder.toString());
//                    Message msg = new Message();
//                    // 将builder中的内容设置到msg里
//                    msg.obj = builder;
//                    // 发送消息
//                    handler.sendMessage(msg);
//
//                    // 关闭进度条
//                    dialog.dismiss();
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        };
//        t.start();


    //读取txt文档内容
//    private String loadData(String path){
//        DisplayMetrics metrics=new DisplayMetrics();
//        screenHeight=metrics.heightPixels;
//        screenWidth=metrics.widthPixels;
//        File file = new File(path);
//        BufferedReader br = null;
//        StringBuffer sb = new StringBuffer();
//        try{
//            String code=resolveCode(path);
//            br  = new BufferedReader(new InputStreamReader(new FileInputStream(file), code));//根据编码读取文件数据流
//
//            String line = "";
//            while ((line = br.readLine()) != null){
//                sb.append(line);//添加数据
//                sb.append('\n');
//                fileLength=fileLength+1;
//            }
//
//
//            br.close();
//        }catch (Exception e){
//            Toast.makeText(this,"读取此文本出现错误，请重试",Toast.LENGTH_SHORT).show();
//        }
//        return sb.toString();
//    }







    public static String resolveCode(String path) throws Exception {

        InputStream inputStream = new FileInputStream(path);
        byte[] head = new byte[3];
        inputStream.read(head);
        String code = "GBK";  //或GBK
        if (head[0] == -1 && head[1] == -2 )
            code = "UTF-16";
        else if (head[0] == -2 && head[1] == -1 )
            code = "Unicode";
        else if(head[0]==-17 && head[1]==-69 && head[2] ==-65)
            code = "UTF-8";

        inputStream.close();

        System.out.println(code);
        return code;
    }


    @Override
    public void onClick(View v) {
//        switch (v.getId()){
//            case R.id.chapter:
//                Intent intent1=new Intent(ReadingActivity.this,ChapterMenu.class);
//                intent1.putExtra("path",path);
//                startActivityForResult(intent1,REQUEST_CODE1);
//            case R.id.size:
//                Intent intent=new Intent(ReadingActivity.this,SizeSetting.class);
//                startActivityForResult(intent,REQUEST_CODE2);
//
//        }

    }


    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        return false;
    }
}
