package com.example.reading;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;

public class Page {
    private String path;
    private long pages;
    private final int SIZE=2000;
    private long bytescount;
    private int currentpage;
    private String encode;
    private RandomAccessFile readFile;
    private int screenHeight;
    private int screenWidth;
    private int textSize=20;
    private int lineNumber;
    private int columnNumber;
    private int pageNumber;
    private int fileLength;
    private int lineHeight;


    private Paint mPaint;
    private Canvas mCanvas;

    private MappedByteBuffer mappedFile;
    private RandomAccessFile randomFile;

    private int begin;
    private int end;
    private Context mContext;
    private View mView;

    //    private String content;
    private ArrayList<String> content=new ArrayList<>();

    public void setEncode(String encode) {
        this.encode = encode;
    }

    public void setScreenHeight(int screenHeight) {
        this.screenHeight = screenHeight;
    }

    public void setScreenWidth(int screenWidth) {
        this.screenWidth = screenWidth;
    }

    public void setTextSize(int textSize) {
        this.textSize = textSize;
    }

    public void setLineHeight(int lineHeight) {
        this.lineHeight = lineHeight;
    }

    public int getCurrentpage() {
        return currentpage;
    }

    public Page(String path, int currentpage){
        try{
            File file=new File(path);
            readFile=new RandomAccessFile(file,"r");
            bytescount=readFile.length();//获得字节总数
            pages=bytescount/SIZE;//计算得出文本的页数
            this.currentpage=currentpage;
        }
        catch(Exception e){
            e.printStackTrace();
        }




    }

    private void seek(int page){
        try{
            readFile.seek(page*SIZE);
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

    public String change_page(int page){
        String content=null;
        this.currentpage=page;
        seek(page);
        content=read();


        return content;

    }
    private String read(){
        byte[] chs=new byte[SIZE];
        try{
            readFile.read(chs);
        }
        catch (IOException e){
            e.printStackTrace();
        }
        return new String(chs, Charset.forName(encode));
    }

    public String getPre(){
        String content=null;
        if (currentpage<=1){
            seek(currentpage-1);
            content=read();

        }else
        {
            seek(currentpage-2);

            content=read();
            currentpage=currentpage-1;

        }
        return content;
    }
    public String getNext(){
        String content=null;
        if(currentpage>=pages){
            seek(currentpage-1);
            content=read();
        }else {
            seek(currentpage-1);
            content=read();
            currentpage=currentpage+1;
        }
        return content;

    }
//    public ArrayList<String> nextPage(){
//    if(end >= fileLength){
//
//    }else{
//        content.clear();
//        begin = end;
//        pageDown();
//
//    }
//    return content;
//}
////    上一页
//    public ArrayList<String>  prePage(){
//        if(begin <= 0){
//
//        }else{
//            content.clear();
//            pageUp();
//            end = begin;
//            pageDown();
//        }
//        return content;
//    }
//
//
//    //向后读取一个段落，返回bytes
//    private byte[] readParagraphForward(int end){
//        byte b0;
//        int i = end;
//        while(i < fileLength){
//            b0 = mappedFile.get(i);
//            if(b0 == 10) {
//                break;
//            }
//            i++;
//        }
//        i = Math.min(fileLength-1,i);
//
//        int nParaSize = i - end + 1 ;
//
//        byte[] buf = new byte[nParaSize];
//        for (i = 0; i < nParaSize; i++) {
//            buf[i] =  mappedFile.get(end + i);
//        }
//        return buf;
//    }
//    //向前读取一个段落
//    private byte[] readParagraphBack(int begin){
//        byte b0 ;
//        int i = begin -1 ;
//        while(i > 0){
//            b0 = mappedFile.get(i);
//            if(b0 == 0x0a && i != begin -1 ){
//                i++;
//                break;
//            }
//            i--;
//        }
//        int nParaSize = begin -i ;
//        byte[] buf = new byte[nParaSize];
//        for (int j = 0; j < nParaSize; j++) {
//            buf[j] = mappedFile.get(i + j);
//        }
//        return buf;
//
//    }
//    //获取后一页的内容
//    private void pageDown(){
//        String strParagraph = "";
//        while((content.size()<lineNumber) && (end< fileLength)){
//            byte[] byteTemp = readParagraphForward(end);
//            end += byteTemp.length;
//            try{
//                strParagraph = new String(byteTemp, encode);
//            }catch(Exception e){
//                e.printStackTrace();
//            }
//            strParagraph = strParagraph.replaceAll("\r\n","  ");
//            strParagraph = strParagraph.replaceAll("\n", " ");
//            //计算每行需要的字数，切断string放入list中
//            while(strParagraph.length() >  0){
//                int size = mPaint.breakText(strParagraph,true,screenWidth,null);
//                content.add(strParagraph.substring(0,size));
//                strParagraph = strParagraph.substring(size);
//                if(content.size() >= lineNumber){
//                    break;
//                }
//            }
//            //如有剩余，则将指针回退
//            if(strParagraph.length()>0){
//                try{
//                    end -= (strParagraph).getBytes(encode).length;
//                }catch(Exception e){
//                    e.printStackTrace();
//                }
//            }
//
//        }
//    }
//    //读取前一页的内容
//    private  void pageUp(){
//        String strParagraph = "";
//        List<String> tempList = new ArrayList<>();
//        while(tempList.size()<lineNumber && begin>0){
//            byte[] byteTemp = readParagraphBack(begin);
//            begin -= byteTemp.length;
//            try{
//                strParagraph = new String(byteTemp, encode);
//            }catch(Exception e){
//                e.printStackTrace();
//            }
//            strParagraph = strParagraph.replaceAll("\r\n","  ");
//            strParagraph = strParagraph.replaceAll("\n","  ");
//            while(strParagraph.length() > 0){
//                int size = mPaint.breakText(strParagraph,true,screenWidth,null);
//                tempList.add(strParagraph.substring(0, size));
//                strParagraph = strParagraph.substring(size);
//                if(tempList.size() >= lineNumber){
//                    break;
//                }
//            }
//            if(strParagraph.length() > 0){
//                try{
//                    begin+= strParagraph.getBytes(encode).length;
//                }catch(Exception e){
//                    e.printStackTrace();
//                }
//            }
//        }
//    }

}

