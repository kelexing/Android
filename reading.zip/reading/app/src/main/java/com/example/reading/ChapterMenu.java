package com.example.reading;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

public class ChapterMenu extends AppCompatActivity {

    private List<Chapter> chapterList = new ArrayList<>();
    private String path;
    private Chapter chapter1;
    private MappedByteBuffer mappedFile;//映射到内存中的文件
    private RandomAccessFile randomFile;//关闭Random流时使用
    private int fileLength;
    final int RESULT_CODE1=101;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.chapter);
        ActionBar actionBar =getSupportActionBar();
        if(actionBar!=null){
            actionBar.hide();
        }
        Intent intent=getIntent();
        path=getIntent().getStringExtra("path");//获取点击文件路径
        File file=new File(path);
        fileLength=(int)file.length();
        try{
            randomFile=new RandomAccessFile(file,"r");
            mappedFile=randomFile.getChannel().map(FileChannel.MapMode.READ_ONLY,0,(long)fileLength);
        }    catch (Exception e){
            e.printStackTrace();
        }


//        initChapter(s);
        chapterList=findChapterParagraphPosition();

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.chapter_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        final ChapterAdapter adapter = new ChapterAdapter(chapterList);
        adapter.setClickListener(new ChapterAdapter.ChapterListItemClickListener() {
            @Override
            public void onClick(View view, int position) {
                int chapterbyte=chapterList.get(position).getChapter_byte_position();
                Toast.makeText(ChapterMenu.this,"byte"+chapterList.get(position).getChapter_byte_position(),Toast.LENGTH_LONG).show();
                Intent intent=new Intent(ChapterMenu.this,ReadingActivity.class);
                intent.putExtra("chapterbyte",chapterbyte);

                setResult(RESULT_CODE1,intent);
                finish();
            }
        });
        recyclerView.setAdapter(adapter);


    }
//    private void initChapter(String path){
//
//        String encoding= null;
//        try {
//            encoding = resolveCode(path);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        int i = 0;
//        try {
//            InputStreamReader isr = new InputStreamReader(new FileInputStream(new File(path)), encoding);
//            BufferedReader reader = new BufferedReader(isr);
//            String temp;
//            Chapter chapter;
//            while ((temp = reader.readLine()) != null) {
//                //这里关键字可以是章，也可以是其他的什么
//                if(temp.contains("第")&&temp.contains("章")){
//                    chapter = new Chapter(temp,i);
//                    Log.d("123","章节"+temp);
//
//
//                    chapterList.add(chapter);
//                }
//                i++;
//            }
//        } catch (FileNotFoundException f) {
//            f.printStackTrace();
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//    }
      private List<Chapter>  findChapterParagraphPosition(){
        List<Chapter> list =new ArrayList<>();
          String encoding= null;
        try {
            encoding = resolveCode(path);
        } catch (Exception e) {
            e.printStackTrace();
        }
        int i=0;
        try{
            InputStreamReader isr = new InputStreamReader(new FileInputStream(new File(path)), encoding);
            BufferedReader reader = new BufferedReader(isr);
            String temp;
            Chapter chapter;
            while((temp=reader.readLine())!=null){
                if(temp.contains("第")&&temp.contains("章")){
                    chapter=new Chapter();
                    chapter.setChapter_name(temp);
                    chapter.setChapter_position(i);
                    chapter.setChapter_byte_position(findParagraphInBytePosition().get(chapter.getChapter_position()));
                    list.add(chapter);
                }
                i++;
            }
        }catch (FileNotFoundException f){
            f.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
        return list;
      }
      private List<Integer> findParagraphInBytePosition(){
        List<Integer> list=new ArrayList<>();
        byte[] fileByte=new byte[fileLength];
        mappedFile.get(fileByte);
        mappedFile.position(0);
        for(int i=0;i<fileLength;i++){
            if(fileByte[i]==0x0a){
                list.add(i+1);

            }
        }
        return list;
      }
//      private void insert(){
//        for(Chapter chapter:findChapterParagraphPosition()){
//            chapter.setChapter_byte_position(findParagraphInBytePosition().get(chapter.getChapter_position()));
//        }
//      }


    public static String resolveCode(String path) throws Exception {

        InputStream inputStream = new FileInputStream(path);
        byte[] head = new byte[3];
        inputStream.read(head);
        String code = "GBK";  //或GBK
        if (head[0] == -1 && head[1] == -2 )
            code = "UTF-16";
        else if (head[0] == -2 && head[1] == -1 )
            code = "Unicode";
        else if(head[0]==-17 && head[1]==-69 && head[2] ==-65)
            code = "UTF-8";

        inputStream.close();

        System.out.println(code);
        return code;
    }


}

