package com.nullptr.imamusicplayer.TAG;

public class PlayerMsg {
    final public static int PLAY_MSG = 0;
    final public static int PAUSE_MSG = 1;
    final public static int STOP_MSG = 2;
}
